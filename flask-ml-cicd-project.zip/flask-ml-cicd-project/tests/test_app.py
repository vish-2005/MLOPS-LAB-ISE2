import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import app

def client(): return app.test_client()

def test_health():
    r = client().get("/health"); assert r.status_code == 200 and r.json["status"] == "ok"

def test_home_page():
    assert b"Iris Species Predictor" in client().get("/").data

def test_api_predict():
    r = client().post("/api/predict", json=dict(sepal_length=5.1, sepal_width=3.5, petal_length=1.4, petal_width=0.2))
    assert r.status_code == 200 and r.json["species"] == "setosa"

def test_api_bad_input():
    assert client().post("/api/predict", json={"sepal_length": "x"}).status_code == 400

def test_metrics():
    assert b"app_requests_total" in client().get("/metrics").data
