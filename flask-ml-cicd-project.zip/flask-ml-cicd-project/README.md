# Flask ML Web App - CI/CD with Jenkins, Docker and Prometheus/Grafana Monitoring

Iris species predictor (Flask + scikit-learn) with a CI/CD pipeline and monitoring.

## Run locally
    python -m venv venv
    venv\Scripts\activate
    pip install -r requirements.txt
    python -m pytest -v
    python app.py            # http://localhost:5000

## Run with Docker + monitoring
    docker compose up -d --build
- App: http://localhost:5000  (health: /health, metrics: /metrics)
- Prometheus: http://localhost:9090 (Status > Targets should show flask-ml-app UP)
- Grafana: http://localhost:3000 (admin/admin) - add Prometheus data source http://prometheus:9090

## CI/CD
`Jenkinsfile` stages: Checkout > Install Dependencies > Test > Build Docker Image > Deploy > Verify
