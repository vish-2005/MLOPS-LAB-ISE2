import os, time
import joblib
from flask import Flask, render_template, request, jsonify, Response
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier

app = Flask(__name__)
MODEL_PATH = "model.joblib"
CLASSES = ["setosa", "versicolor", "virginica"]

def load_model():
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)
    X, y = load_iris(return_X_y=True)
    m = RandomForestClassifier(n_estimators=100, random_state=42).fit(X, y)
    joblib.dump(m, MODEL_PATH)
    return m

model = load_model()

REQUESTS = Counter("app_requests_total", "Total HTTP requests", ["endpoint", "method"])
PREDICTIONS = Counter("app_predictions_total", "Predictions made", ["species"])
ERRORS = Counter("app_prediction_errors_total", "Invalid prediction requests")
LATENCY = Histogram("app_prediction_latency_seconds", "Prediction latency")

def predict(values):
    start = time.time()
    species = CLASSES[int(model.predict([values])[0])]
    LATENCY.observe(time.time() - start)
    PREDICTIONS.labels(species).inc()
    return species

@app.route("/", methods=["GET", "POST"])
def home():
    REQUESTS.labels("/", request.method).inc()
    result = error = None
    if request.method == "POST":
        try:
            vals = [float(request.form[k]) for k in ("sl", "sw", "pl", "pw")]
            result = predict(vals)
        except (KeyError, ValueError):
            ERRORS.inc(); error = "Please enter four valid numbers."
    return render_template("index.html", result=result, error=error)

@app.route("/api/predict", methods=["POST"])
def api_predict():
    REQUESTS.labels("/api/predict", "POST").inc()
    data = request.get_json(silent=True) or {}
    try:
        vals = [float(data[k]) for k in ("sepal_length", "sepal_width", "petal_length", "petal_width")]
    except (KeyError, ValueError, TypeError):
        ERRORS.inc()
        return jsonify(error="Provide sepal_length, sepal_width, petal_length, petal_width as numbers"), 400
    return jsonify(species=predict(vals))

@app.route("/health")
def health():
    return jsonify(status="ok")

@app.route("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
